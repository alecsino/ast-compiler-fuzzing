#pragma GCC system_header
enum E { _A, _B, _C };
