/* { dg-do run } */
/* { dg-skip-if "not implemented" { powerpc*-*-aix* } } */
/* { dg-options "-O2 -fzero-call-used-regs=used" } */

#include "zero-scratch-regs-1.c"
