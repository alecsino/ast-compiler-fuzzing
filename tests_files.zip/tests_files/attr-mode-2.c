typedef int I;
int x;
I y __attribute__ ((mode(QI)));
extern I x;
