/* { dg-do run } */
/* { dg-options "-O2 -fzero-call-used-regs=used-gpr-arg" } */

#include "zero-scratch-regs-1.c"
