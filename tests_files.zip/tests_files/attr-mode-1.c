// PR c/100545
// { dg-additional-options -g }

typedef int fatp_t __attribute__((aligned, mode(SI)));
