/* PR c/65179 */
/* { dg-do compile } */
/* { dg-options "-O -Wextra -fwrapv" } */

#include "Wshift-negative-value-1.c"
