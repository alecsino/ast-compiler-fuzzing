/* Six marker characters at EOF, causes conflict marker detector to peek 4
   tokens. */

/* { dg-error "expected" } */ <<<<<<