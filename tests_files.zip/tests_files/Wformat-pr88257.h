#pragma GCC system_header

/* Whitespace is significant here, due to line numbering.
   See the comment below.














  End of significant whitespace */

#include "empty.h"
/* The preceding include ensures a line map starts here, with a line
   number greater than that of the usage site, to try to trigger
   an assertion failure.  */

# define PRIu32  "u"
