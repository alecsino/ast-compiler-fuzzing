/* PR c/65179 */
/* { dg-do compile } */
/* { dg-options "-O -fwrapv" } */

#include "Wshift-negative-value-1.c"
