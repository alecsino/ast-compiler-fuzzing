/* PR c++/55095 */
/* { dg-do compile { target int32 } } */
/* { dg-options "-Wshift-overflow=2 -fwrapv" } */

#include "Wshift-overflow-7.c"
