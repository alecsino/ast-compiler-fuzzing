/* { dg-do run } */
/* { dg-skip-if "not implemented" { ia64*-*-* } } */
/* { dg-options "-O2 -fzero-call-used-regs=all-gpr-arg" } */

#include "zero-scratch-regs-1.c"
