/* PR c++/55095 */
/* { dg-do compile { target int32 } } */
/* { dg-options "-Wshift-overflow=1 -fwrapv" } */

#include "Wshift-overflow-6.c"
