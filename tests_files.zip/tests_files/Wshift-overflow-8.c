/* PR c++/55095 */
/* { dg-do compile { target int32 } } */
/* { dg-options "-O -fwrapv" } */

#include "Wshift-overflow-1.c"
