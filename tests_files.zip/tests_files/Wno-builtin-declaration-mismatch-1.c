/* PR c++/82466 */
/* { dg-options "-Wno-builtin-declaration-mismatch" } */

int printf;
