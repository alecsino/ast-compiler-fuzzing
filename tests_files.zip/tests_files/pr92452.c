/* PR tree-optimization/92452 */
/* { dg-do compile } */
/* { dg-options "-Os -Warray-bounds=1" } */

#include "pr60101.c"
