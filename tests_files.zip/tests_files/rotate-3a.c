/* { dg-do run } */
/* { dg-options "-O2 -Wno-overflow" } */

#define ROTATE_N "rotate-4.c"

#include "rotate-1a.c"
