/* This should not be flagged as a conflict marker.  */
const char *msg = "<<<<<<< ";
