/* { dg-do run } */
/* { dg-options "-O2 -Wno-overflow" } */

#define ROTATE_N "rotate-6.c"

#include "rotate-1a.c"
