#pragma GCC system_header
struct {
  enum { _A } b;
} c;
