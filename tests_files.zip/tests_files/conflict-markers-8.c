/* A macro that's never expanded shouldn't be reported as a
   conflict marker.  */
#define foo \
<<<<<<<
