/* { dg-do compile } */
/* { dg-options "-fcf-protection=none" } */
